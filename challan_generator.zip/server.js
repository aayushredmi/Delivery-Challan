const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const puppeteer = require('puppeteer');
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');

app.get('/', (req, res) => res.sendFile(__dirname + '/index.html'));

app.post('/generate', async (req, res) => {
  const data = req.body;
  const html = await ejs.renderFile(__dirname + '/views/template.ejs', { data });

  const browser = await puppeteer.launch();
  const page = await browser.newPage();
  await page.setContent(html);
  const pdf = await page.pdf({ format: 'A4' });
  await browser.close();

  res.setHeader('Content-Disposition', 'attachment; filename=challan.pdf');
  res.contentType("application/pdf");
  res.send(pdf);
});

app.listen(3000, () => console.log("Server running on http://localhost:3000"));
